-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2022 at 12:59 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_antrian`
--

-- --------------------------------------------------------

--
-- Table structure for table `antrian`
--

CREATE TABLE `antrian` (
  `antrian_id` int(11) NOT NULL,
  `tanggal` datetime DEFAULT current_timestamp(),
  `no_antrian` int(10) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `waktu_panggil` timestamp NULL DEFAULT current_timestamp(),
  `waktu_selesai` timestamp NULL DEFAULT current_timestamp(),
  `pelayanan_id` int(11) DEFAULT NULL,
  `loket_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `antrian`
--

INSERT INTO `antrian` (`antrian_id`, `tanggal`, `no_antrian`, `status`, `waktu_panggil`, `waktu_selesai`, `pelayanan_id`, `loket_id`) VALUES
(25, '2022-07-08 05:19:13', NULL, 1, '2022-07-07 22:22:50', '2022-07-07 22:22:50', 4, 18),
(26, '2022-07-08 05:19:24', NULL, 1, '2022-07-07 22:21:17', NULL, 6, 19),
(27, '2022-07-08 05:19:34', NULL, 1, '2022-07-07 22:21:25', NULL, 3, 18),
(28, '2022-07-08 05:52:13', NULL, NULL, NULL, NULL, 4, 19);

-- --------------------------------------------------------

--
-- Table structure for table `loket`
--

CREATE TABLE `loket` (
  `loket_id` int(11) NOT NULL,
  `nama_loket` varchar(100) DEFAULT NULL,
  `keterangan` tinytext DEFAULT NULL,
  `pelayanan_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loket`
--

INSERT INTO `loket` (`loket_id`, `nama_loket`, `keterangan`, `pelayanan_id`) VALUES
(18, 'Loket 1', 'ini loket 1', 2),
(19, 'Loket 2', 'ini loket 2', 2),
(20, 'Loket 3', 'ini loket 3', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pelayanan`
--

CREATE TABLE `pelayanan` (
  `pelayanan_id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `keterangan_ply` tinytext DEFAULT NULL,
  `kode` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelayanan`
--

INSERT INTO `pelayanan` (`pelayanan_id`, `nama`, `keterangan_ply`, `kode`) VALUES
(2, 'Customer Service', 'ini pelayanan cs', 'P1'),
(3, 'Permohonan Baru', 'ini adalah jenis pelayanan permohonan baru', 'P2'),
(4, 'Pengaduan', 'ini adalah jenis pelayanan pengaduan', 'P3'),
(6, 'Perpanjangan baru', 'ini adalah jenis pelayanan perpanjangan', 'P4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `antrian`
--
ALTER TABLE `antrian`
  ADD PRIMARY KEY (`antrian_id`),
  ADD KEY `pelayanan_id` (`pelayanan_id`),
  ADD KEY `loket_id` (`loket_id`);

--
-- Indexes for table `loket`
--
ALTER TABLE `loket`
  ADD PRIMARY KEY (`loket_id`),
  ADD KEY `pelayanan_id` (`pelayanan_id`);

--
-- Indexes for table `pelayanan`
--
ALTER TABLE `pelayanan`
  ADD PRIMARY KEY (`pelayanan_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `antrian`
--
ALTER TABLE `antrian`
  MODIFY `antrian_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `loket`
--
ALTER TABLE `loket`
  MODIFY `loket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `pelayanan`
--
ALTER TABLE `pelayanan`
  MODIFY `pelayanan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `antrian`
--
ALTER TABLE `antrian`
  ADD CONSTRAINT `antrian_ibfk_1` FOREIGN KEY (`pelayanan_id`) REFERENCES `pelayanan` (`pelayanan_id`),
  ADD CONSTRAINT `antrian_ibfk_2` FOREIGN KEY (`loket_id`) REFERENCES `loket` (`loket_id`);

--
-- Constraints for table `loket`
--
ALTER TABLE `loket`
  ADD CONSTRAINT `loket_ibfk_1` FOREIGN KEY (`pelayanan_id`) REFERENCES `pelayanan` (`pelayanan_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
